<!DOCTYPE html>
<html>
<head>
    <title>Login Signup System</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="container">

    <h1>Welcome</h1>
    <h2>Login & Signup System</h2>

    <a href="login.jsp">
        <button>Login</button>
    </a>

    <br><br>

    <a href="signup.jsp">
        <button>Signup</button>
    </a>

</div>

</body>
</html>