<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="container">

    <form action="signup" method="post" class="form">

        <h2>Create Account</h2>

        <input type="text" 
               name="name" 
               placeholder="Enter Name" 
               required>

        <input type="email" 
               name="email" 
               placeholder="Enter Email" 
               required>

        <input type="password" 
               name="password" 
               placeholder="Enter Password" 
               required>

        <button type="submit">Signup</button>

        <p>
            Already have an account?
            <a href="login.jsp">Login</a>
        </p>

    </form>

</div>

</body>
</html>