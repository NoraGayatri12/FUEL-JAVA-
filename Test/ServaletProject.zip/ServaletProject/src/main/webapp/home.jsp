<%@ page session="true" %>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<h2>Welcome ${sessionScope.user}</h2>

<a href="logout">Logout</a>

</body>
</html>