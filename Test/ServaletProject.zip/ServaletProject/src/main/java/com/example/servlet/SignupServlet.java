package com.example.servlet;

import com.example.util.DataConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/signup")
public class SignupServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection con = DataConnection.getConnection()) {

            String sql = "INSERT INTO users(name,email,password) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);

            int i = ps.executeUpdate();

            if (i > 0) {

                out.println("<h2>Signup Successful!</h2>");
                out.println("<a href='login.jsp'>Go to Login</a>");

            } else {

                out.println("<h2>Signup Failed</h2>");

            }

        } catch (Exception e) {

            out.println("<h3>Error: " + e.getMessage() + "</h3>");
            e.printStackTrace();

        }
    }
}